﻿execute if score @s cds.deaths > @s cds.prev run function custom_death_sound:play_death_sound
scoreboard players operation @s cds.prev = @s cds.deaths