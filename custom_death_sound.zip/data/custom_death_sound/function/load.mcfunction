﻿scoreboard objectives add cds.deaths deathCount
scoreboard objectives add cds.prev dummy
scoreboard objectives add cds.vol dummy
scoreboard players set cds.volume cds.vol 2
tellraw @a [{"text":"[Custom Death Sound] ","color":"gold"},{"text":"Loaded! Volume: /function custom_death_sound:set_volume/low|medium|high","color":"gray"}]