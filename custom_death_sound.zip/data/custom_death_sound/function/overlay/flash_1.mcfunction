﻿title @a times 0 4 3
title @a title {"text":"","font":"custom_death_sound:death_overlay","color":"white"}
schedule function custom_death_sound:overlay/flash_2 7t