﻿title @a times 0 3 4
title @a title {"text":"","font":"custom_death_sound:death_overlay","color":"white"}
schedule function custom_death_sound:overlay/flash_3 7t