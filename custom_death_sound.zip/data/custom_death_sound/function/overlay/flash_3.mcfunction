﻿title @a times 0 2 25
title @a title {"text":"","font":"custom_death_sound:death_overlay","color":"white"}