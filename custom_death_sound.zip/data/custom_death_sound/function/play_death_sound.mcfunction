﻿execute if score cds.volume cds.vol matches 1 run playsound custom_death_sound:death_sound master @a ~ ~ ~ 0.5 1.0
execute if score cds.volume cds.vol matches 2 run playsound custom_death_sound:death_sound master @a ~ ~ ~ 1.0 1.0
execute if score cds.volume cds.vol matches 3 run playsound custom_death_sound:death_sound master @a ~ ~ ~ 2.0 1.0
function custom_death_sound:overlay/flash_1