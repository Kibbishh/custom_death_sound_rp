﻿scoreboard players set cds.volume cds.vol 3
tellraw @a [{"text":"[Custom Death Sound] ","color":"gold"},{"text":"Volume set to HIGH","color":"red"}]