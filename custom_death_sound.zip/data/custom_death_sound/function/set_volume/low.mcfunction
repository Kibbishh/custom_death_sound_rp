﻿scoreboard players set cds.volume cds.vol 1
tellraw @a [{"text":"[Custom Death Sound] ","color":"gold"},{"text":"Volume set to LOW","color":"yellow"}]