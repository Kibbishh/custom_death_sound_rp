﻿scoreboard players set cds.volume cds.vol 2
tellraw @a [{"text":"[Custom Death Sound] ","color":"gold"},{"text":"Volume set to MEDIUM","color":"green"}]